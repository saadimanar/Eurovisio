#include <stdio.h>
#include <stdlib.h>
#include "eurovisionTests.h"
#include "map.h"
#include "eurovision.h"
#include <stdbool.h>
#include <string.h>
#include <math.h>
#include "test_utilities.h"
#include "test_utilitiesFace.h"
#include "state.h"
#include "judge.h"
#include "assert.h"

#define TEST(t)                                                               \
  do {                                                                         \
    printf("Testing %s ...\n", #t);                                            \
    if ((t()))                                                                 \
      printf("Test %s: SUCCESS\n", #t);                                        \
    else                                                                       \
      printf("Test %s: FAIL\n", #t);                                           \
  } while (0);

#define POINTS_OPTIONS_NUMBER 10
#define CHECK(b,res)                            \
  if((b) != (res)) do{                          \
      printf("fail: %s != %s\n", #b, #res);     \
      eurovisionDestroy(eurovision);            \
      return false;                             \
    } while(0)

static Eurovision setupEurovision() {
    Eurovision eurovision = eurovisionCreate();
    assert(eurovision);
    return eurovision;
}

static void setupEurovision10_states(Eurovision eurovision) {
    eurovisionAddState(eurovision, 0, "zero", "home");
    eurovisionAddState(eurovision, 1, "one", "chameleon");
    eurovisionAddState(eurovision, 2, "two", "the dream");
    eurovisionAddState(eurovision, 3, "three", "scream");
    eurovisionAddState(eurovision, 4, "four", "stay");
    eurovisionAddState(eurovision, 5, "five", "replay");
    eurovisionAddState(eurovision, 6, "six", "la venda");
    eurovisionAddState(eurovision, 7, "seven", "soldi");
    eurovisionAddState(eurovision, 8, "eight", "roi");
    eurovisionAddState(eurovision, 9, "nine", "sister");
}

static int *makeJudgeResults(int id0, int id1, int id2, int id3, int id4,
                             int id5, int id6, int id7, int id8, int id9) {
    int *results = malloc(POINTS_OPTIONS_NUMBER * sizeof(*results));
    assert(results);
    results[0] = id0;
    results[1] = id1;
    results[2] = id2;
    results[3] = id3;
    results[4] = id4;
    results[5] = id5;
    results[6] = id6;
    results[7] = id7;
    results[8] = id8;
    results[9] = id9;
    return results;
}


//The following block contains compare/copy/free function for Integers
static MapKeyElement copyInt(MapKeyElement e) {
    int *newInt = malloc(sizeof(int));
    if (newInt == NULL) return NULL;
    *newInt = *(int *) e;
    return newInt;
}

static void freeInt(MapKeyElement e) {
    free(e);
}

static int compareInt(MapKeyElement a, MapKeyElement b) {
    return *(int *) a - *(int *) b;
}


//The tests block
static int createDestroyTest(int *tests_passed) {
    _print_mode_name("Testing Create&Destroy functions");
    int test_number = 1;
    _print_test_number(test_number, __LINE__);
    Map map = mapCreate(NULL, copyInt, freeInt, freeInt, compareInt);
    test(map != NULL, __LINE__, &test_number, "mapCreate doesn't return NULL on NULL CopyDataElement", tests_passed);
    map = mapCreate(copyInt, NULL, freeInt, freeInt, compareInt);
    test(map != NULL, __LINE__, &test_number, "mapCreate doesn't return NULL on NULL CopyKeyElement", tests_passed);
    map = mapCreate(copyInt, copyInt, NULL, freeInt, compareInt);
    test(map != NULL, __LINE__, &test_number, "mapCreate doesn't return NULL on NULL FreeDataElement", tests_passed);
    map = mapCreate(copyInt, copyInt, freeInt, NULL, compareInt);
    test(map != NULL, __LINE__, &test_number, "mapCreate doesn't return NULL on NULL FreeKeyElement", tests_passed);
    map = mapCreate(copyInt, copyInt, freeInt, freeInt, NULL);
    test(map != NULL, __LINE__, &test_number, "mapCreate doesn't return NULL on NULL CompareKeyElement", tests_passed);
    map = mapCreate(copyInt, copyInt, freeInt, freeInt, compareInt);
    test(map == NULL, __LINE__, &test_number, "mapCreate returns NULL on Valid input", tests_passed);
    mapDestroy(NULL); // A silent test which check if the function doesn't crash on NULL input.
    _print_test_success(test_number);
    *tests_passed += 1;
    mapDestroy(map);
    return test_number;
}

static int mapPutTest(int *tests_passed) {
    _print_mode_name("Testing mapPut function");
    int test_number = 1;
    int a[6] = {0, 1, 2, 3, 4, 5};
    Map map = mapCreate(copyInt, copyInt, freeInt, freeInt, compareInt);
    MapResult mr;
    _print_test_number(test_number, __LINE__);
    mr = mapPut(NULL, &a[0], &a[1]);
    test( mr != MAP_NULL_ARGUMENT , __LINE__, &test_number, "mapPut doesn't return MAP_NULL_ARGUMENT on NULL map input", tests_passed);
    mr = mapPut(map, NULL, &a[1]);
    test( mr == MAP_SUCCESS , __LINE__, &test_number, "mapPut return MAP_SUCCESS on NULL key input", tests_passed);
    mr = mapPut(map, &a[0], NULL);
    test( mr == MAP_SUCCESS , __LINE__, &test_number, "mapPut return MAP_SUCCESS on NULL data input", tests_passed);
    mr = mapPut(map, &a[0], &a[1]);
    test( mr != MAP_SUCCESS , __LINE__, &test_number, "mapPut doesn't return MAP_SUCCESS on valid data input", tests_passed);
    mapPut(map, &a[2], &a[3]);
    mapGetFirst(map);
    mapPut(map, &a[4], &a[5]);                         //Implementation dependent
    test( mapGetNext(map) != NULL, __LINE__, &test_number, "mapPut doesn't set iterator be NULL after insertion", tests_passed);
    bool ordered = true;
    int k = 0;
    MAP_FOREACH(int*, i, map) {
        if((a[k] != *i)) {
            ordered = false;
            break;
        }
        k+=2;
    }//                                         Inserting keys order: low->mid->high
    test( !ordered , __LINE__, &test_number, "mapPut doesn't order the keys correctly, Insertion from low to high", tests_passed);
    mapDestroy(map);
    map = mapCreate(copyInt, copyInt, freeInt, freeInt, compareInt);
    mapPut(map, &a[4], &a[5]);
    mapPut(map, &a[2], &a[3]);
    mapPut(map, &a[0], &a[1]);
    ordered = true;
    k = 0;
    MAP_FOREACH(int*, i, map) {
        if((a[k] != *i)) {
            ordered = false;
            break;
        }
        k+=2;
    }//                                         Inserting keys order: high->mid->low
    test( !ordered , __LINE__, &test_number, "mapPut doesn't order the keys correctly, Insertion from high to low", tests_passed);
    mapDestroy(map);
    map = mapCreate(copyInt, copyInt, freeInt, freeInt, compareInt);
    mapPut(map, &a[2], &a[3]);
    mapPut(map, &a[4], &a[5]);
    mapPut(map, &a[0], &a[1]);
    k = 0;
    ordered = true;
    MAP_FOREACH(int*, i, map) {
        if((a[k] != *i)) {
            ordered = false;
            break;
        }
        k+=2;
    }//                                            Inserting keys order: small->high->middle(in between them)
    test( !ordered , __LINE__, &test_number, "mapPut doesn't order the keys correctly, Insertion in the middle", tests_passed);
    mr = mapPut(map, &a[2], &a[1]);
    test( mr != MAP_SUCCESS , __LINE__, &test_number, "mapPut doesn't allow to Re-write data on existing key", tests_passed);
    MapDataElement data = mapGet(map, &a[2]);
    test( *(int *)data != a[1] , __LINE__, &test_number, "mapPut doesn't rewrite the data on existing key", tests_passed);
    _print_test_success(test_number);
    *tests_passed += 1;
    mapDestroy(map);
    return test_number;
}

static int mapGetSizeTest(int *tests_passed) {
    _print_mode_name("Testing mapGetSize function");
    int test_number = 1;
    _print_test_number(test_number, __LINE__);
    test( mapGetSize(NULL) != -1 , __LINE__, &test_number, "mapGetSize doesn't return -1 on NULL map Input", tests_passed);
    Map map = mapCreate(copyInt, copyInt, freeInt, freeInt, compareInt);
    test( mapGetSize(map) != 0 , __LINE__, &test_number, "mapGetSize doesn't return 0 on empty map Input", tests_passed);
    int a[2] = {0, 1};
    mapPut(map, &a[0], &a[1]);
    test( mapGetSize(map) != 1 , __LINE__, &test_number, "mapGetSize doesn't return right value", tests_passed);
    _print_test_success(test_number);
    *tests_passed += 1;
    mapDestroy(map);
    return test_number;
}

static int mapCopyTest(int *tests_passed) {
    _print_mode_name("Testing mapCopyTest function");
    int test_number = 1;
    _print_test_number(test_number, __LINE__);
    int a[6] = {0, 1, 2, 3, 4, 5};
    Map map = mapCreate(copyInt, copyInt, freeInt, freeInt, compareInt);
    mapPut(map, &a[0], &a[1]);
    mapPut(map, &a[2], &a[3]);
    mapPut(map, &a[4], &a[5]);
    Map map_copy = mapCopy(map);                          //Assuming mapGetSize works correctly.
    test(mapGetSize(map) != mapGetSize(map_copy), __LINE__, &test_number, "mapCopy doesn't copy every pair of  elements", tests_passed);
    test(mapCopy(NULL) != NULL ,__LINE__, &test_number, "mapCopy doesn't return NULL on NULL input", tests_passed);
    int k = 0;
    bool ordered = true;
    MAP_FOREACH(int*, i, map_copy) {
        if((a[k] != *i)) {
            ordered = false;
            break;
        }
        k+=2;
    }
    test( !ordered , __LINE__, &test_number, "mapCopy doesn't keep the order of the keys", tests_passed);
    _print_test_success(test_number);
    *tests_passed += 1;
    mapDestroy(map);
    mapDestroy(map_copy);
    return test_number;
}

static int mapContainsTest(int *tests_passed) {
    _print_mode_name("Testing mapContains function");
    int test_number = 1;
    _print_test_number(test_number, __LINE__);
    int a[6] = {0, 1, 2, 3, 4, 5};
    Map map = mapCreate(copyInt, copyInt, freeInt, freeInt, compareInt);
    test( mapContains(NULL, &a[0]) != false,__LINE__, &test_number, "mapContain doesn't return false on NULL map input", tests_passed);
    test( mapContains(map, NULL) != false,__LINE__, &test_number, "mapContain doesn't return false on NULL element input", tests_passed);
    test( mapContains(map, &a[0]) != false,__LINE__, &test_number, "mapContain doesn't return false on key which is not in map", tests_passed);
    mapPut(map, &a[0], &a[1]);
    test( !mapContains(map, &a[0]) ,__LINE__, &test_number, "mapCopy doesn't return true on existing element", tests_passed);
    _print_test_success(test_number);
    *tests_passed += 1;
    mapDestroy(map);
    return test_number;
}


static int mapRemoveTest(int *tests_passed) {
    _print_mode_name("Testing mapRemove function");
    int test_number = 1;
    _print_test_number(test_number, __LINE__);
    int a[6] = {0, 1, 2, 3, 4, 5};
    Map map = mapCreate(copyInt, copyInt, freeInt, freeInt, compareInt);
    mapPut(map, &a[0], &a[1]);
    test( mapRemove(NULL, &a[0]) != MAP_NULL_ARGUMENT,__LINE__, &test_number, "mapRemove doesn't return MAP_NULL_ARGUMENT on NULL map input", tests_passed);
    test( mapRemove(map, NULL) != MAP_NULL_ARGUMENT,__LINE__, &test_number, "mapRemove doesn't return MAP_NULL_ARGUMENT on NULL key input", tests_passed);
    test( mapRemove(map, &a[1]) != MAP_ITEM_DOES_NOT_EXIST, __LINE__, &test_number, "mapRemove doesn't return MAP_ITEM_DOES_NOT_EXIST on key not which is not in map", tests_passed);
    test( mapRemove(map, &a[0]) != MAP_SUCCESS, __LINE__, &test_number, "mapRemove doesn't return MAP_SUCCESS after removal", tests_passed);
    test( mapContains(map, &a[0]) == true, __LINE__, &test_number, "mapRemove doesn't remove key from the dictionary", tests_passed);
    //                                                  Implementation dependent
    test( mapGetNext(map) != NULL, __LINE__, &test_number, "mapRemove doesn't set the iterator to be NULL after remove.", tests_passed);
    _print_test_success(test_number);
    *tests_passed += 1;
    mapDestroy(map);
    return test_number;
}

static int mapClearTest(int *tests_passed) {
    _print_mode_name("Testing mapClear function");
    int test_number = 1;
    _print_test_number(test_number, __LINE__);
    int a[6] = {0, 1, 2, 3, 4, 5};
    Map map = mapCreate(copyInt, copyInt, freeInt, freeInt, compareInt);
    mapPut(map, &a[0], &a[1]);
    test( mapClear(NULL) != MAP_NULL_ARGUMENT ,__LINE__, &test_number, "mapClear doesn't return MAP_NULL_ARGUMENT on NULL map input", tests_passed);
    test( mapClear(map) != MAP_SUCCESS , __LINE__, &test_number, "mapClear doesn't return MAP_SUCCESS after clear", tests_passed);
    test( mapContains(map, &a[0]) == true, __LINE__, &test_number, "mapClear doesn't remove elements from the map", tests_passed);
    _print_test_success(test_number);
    *tests_passed += 1;
    mapDestroy(map);
    return test_number;
}

static int mapGetTest(int *tests_passed) {
    _print_mode_name("Testing mapGetFirst/mapGetNext function:");
    int test_number = 1;
    _print_test_number(test_number, __LINE__);
    test( mapGetNext(NULL) != NULL, __LINE__, &test_number, "mapGetNext doesn't return NULL on NULL map input.", tests_passed);
    test( mapGetFirst(NULL) != NULL, __LINE__, &test_number, "mapGetFirst doesn't return NULL on NULL map input.", tests_passed);
    int a[6] = {0, 1, 2, 3, 4, 5};
    Map map = mapCreate(copyInt, copyInt, freeInt, freeInt, compareInt);
    test( mapGetFirst(map) != NULL, __LINE__, &test_number, "mapGetFirst doesn't return NULL on empty map input", tests_passed);
    mapPut(map, &a[0], &a[1]);
    test( compareInt(mapGetFirst(map), &a[0]) != 0, __LINE__, &test_number, "mapGetFirst doesn't return right element", tests_passed);
    MapKeyElement key = mapGetNext(map);
    test( key != NULL, __LINE__, &test_number, "mapGetNext doesn't return NULL at the end of the map", tests_passed);
    mapPut(map, &a[2], &a[3]);
    mapGetFirst(map);
    key = mapGetNext(map);
    test( compareInt(key, &a[2]) != 0, __LINE__, &test_number, "mapGetNext doesn't return right element", tests_passed);
    _print_test_success(test_number);
    *tests_passed += 1;
    mapDestroy(map);
    return test_number;
}

/** Function to be used for copying an int as a key to the map */
static MapKeyElement copyKeyInt(MapKeyElement n) {
    if (!n) {
        return NULL;
    }
    int *copy = malloc(sizeof(*copy));
    if (!copy) {
        return NULL;
    }
    *copy = *(int *) n;
    return copy;
}

/** Function to be used for copying a char as a data to the map */
static MapDataElement copyDataChar(MapDataElement n) {
    if (!n) {
        return NULL;
    }
    char *copy = malloc(sizeof(*copy));
    if (!copy) {
        return NULL;
    }
    *copy = *(char *) n;
    return (MapDataElement) copy;
}

/** Function to be used by the map for freeing elements */
static void freeChar(MapDataElement n) {
    free(n);
}

/** Function to be used by the map for comparing elements */
static int compareInts(MapKeyElement n1, MapKeyElement n2) {
    return (*(int *) n1 - *(int *) n2);
}

bool testMapCreateDestroy() {
    Map map = mapCreate(copyDataChar, copyKeyInt, freeChar, freeInt,
                        compareInts);
    ASSERT_TEST(map != NULL);
    ASSERT_TEST(mapGetSize(map) == 0);
    ASSERT_TEST(mapGetFirst(map) == NULL);
    mapDestroy(map);
    return true;

}

bool testMapAddAndSize() {
    Map map = mapCreate(copyDataChar, copyKeyInt, freeChar, freeInt,
                        compareInts);
    for (int i = 1; i < 1000; ++i) {
        char j = (char) i;
        ++j;
        ASSERT_TEST(mapPut(map, &i, &j) == MAP_SUCCESS);
        ASSERT_TEST(mapGetSize(map) == i);
    }
    mapDestroy(map);
    return true;
}

bool testMapGet() {
    Map map = mapCreate(copyDataChar, copyKeyInt, freeChar, freeInt,
                        compareInts);
    for (int i = 1; i < 1000; ++i) {
        char j = (char) i;
        ++j;
        ASSERT_TEST(mapPut(map, &i, &j) == MAP_SUCCESS);
        ASSERT_TEST(mapGetSize(map) == i);
    }

    for (int i = 1; i < 1000; ++i) {
        char j = (char) i;
        ++j;
        char *getVal = (char *) mapGet(map, &i);
        ASSERT_TEST(*getVal == j);
    }
    int i = 0;
    ASSERT_TEST(mapGet(map, &i) == NULL);
    i = 1000;
    ASSERT_TEST(mapGet(map, &i) == NULL);
    mapDestroy(map);
    return true;
}

bool testIterator() {
    Map map = mapCreate(copyDataChar, copyKeyInt, freeChar, freeInt,
                        compareInts);
    for (int i = 1; i < 400; ++i) {
        char j = (char) i;
        ++j;
        ASSERT_TEST(mapPut(map, &i, &j) == MAP_SUCCESS);
    }

    for (int i = 800; i >= 400; --i) {
        char j = (char) i;
        ++j;
        ASSERT_TEST(mapPut(map, &i, &j) == MAP_SUCCESS);
    }

    for (int i = 801; i < 1000; ++i) {
        char j = (char) i;
        ++j;
        ASSERT_TEST(mapPut(map, &i, &j) == MAP_SUCCESS);
    }

    int i = 1;
    MAP_FOREACH(int *, iter, map) {
        ASSERT_TEST(*iter == i);
        i++;
    }

    mapDestroy(map);
    return true;
}

static void setupEurovisionJudges(Eurovision eurovision) {
    int *results;
    results = makeJudgeResults(0, 1, 2, 3, 4, 5, 6,  7, 8, 9);
    eurovisionAddJudge(eurovision, 0, "olsen", results);
    free(results);
    results = makeJudgeResults(2, 3, 4, 5, 6, 7, 8, 9, 0, 1);
    eurovisionAddJudge(eurovision, 1, "tanel", results);
    free(results);
    results = makeJudgeResults(7, 8, 9, 0, 1, 2, 3,  4, 5, 6);
    eurovisionAddJudge(eurovision, 2, "marie", results);
    free(results);
}

bool testIdOrder(Eurovision eurovision) {
    printf("Testing by ids order: ");
    List result = eurovisionRunContest(eurovision, 100);
    CHECK(listGetSize(result), 10);
    char *current = (char*)listGetFirst(result);
    CHECK(strcmp(current, "zero"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "one"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "two"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "three"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "four"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "five"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "six"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "seven"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "eight"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "nine"), 0);
    printf(" SUCCESS\n");
    listDestroy(result);
    return true;
}

bool testRemoveStateAndJudges() {
    printf("Testing remove state and judges as a result");
    Eurovision eurovision = setupEurovision();
    setupEurovision10_states(eurovision);
    setupEurovisionJudges(eurovision);
    eurovisionRemoveState(eurovision, 0);

    List result = eurovisionRunContest(eurovision, 30);
    CHECK(listGetSize(result), 9);
    char *current = (char*)listGetFirst(result);
    CHECK(strcmp(current, "one"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "two"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "three"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "four"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "five"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "six"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "seven"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "eight"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "nine"), 0);

    listDestroy(result);
    eurovisionDestroy(eurovision);
    printf(": SUCCESS\n");
    return true;
}

bool testJudgesScores () {
    printf("Testing only judges score: ");
    Eurovision eurovision = setupEurovision();
    setupEurovision10_states(eurovision);
    setupEurovisionJudges(eurovision);
    List result = eurovisionRunContest(eurovision, 10);
    CHECK(listGetSize(result), 10);
    char *current = (char*)listGetFirst(result);
    CHECK(strcmp(current, "two"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "zero"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "three"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "seven"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "one"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "four"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "eight"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "five"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "nine"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "six"), 0);
    listDestroy(result);
    printf("SUCCESS\n");

    printf("Testing after deleting one judge: ");
    eurovisionRemoveJudge(eurovision, 0);
    result = eurovisionRunContest(eurovision, 10);
    current = (char*)listGetFirst(result);
    CHECK(strcmp(current, "two"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "seven"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "three"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "eight"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "four"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "nine"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "zero"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "five"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "one"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "six"), 0);
    printf("SUCCESS\n");

    listDestroy(result);
    eurovisionDestroy(eurovision);
    return true;
}
bool testAudienceScores() {
    Eurovision eurovision = setupEurovision();
    setupEurovision10_states(eurovision);
    setupEurovisionJudges(eurovision);
    for (int i=0; i<3; i++) { // testing delete of judges
        eurovisionRemoveJudge(eurovision, i);
    }
    printf("Testing All countries same score: ");
    for(int i=0; i<10; i++) { // each country one vote to other country
        eurovisionAddVote(eurovision, i, (i+1)%10);
    }
    if (testIdOrder(eurovision)) { // check after deleting some countries
        for (int i=0; i<10; i++) {
            eurovisionRemoveVote(eurovision, i+1, i);
        }
        printf("Testing deleting votes that don't exist: ");
        testIdOrder(eurovision);
        for (int i=0; i<10; i++) {
            eurovisionRemoveVote(eurovision, i, (i+1)%10);
        }
        printf("Testing after delete all votes: ");
        testIdOrder(eurovision);
    }
    else {
        eurovisionDestroy(eurovision);
        return false;
    }
    eurovisionDestroy(eurovision);
    return true;
}

bool testFriendly() {
    printf("Testing no friendlies: ");
    Eurovision eurovision = setupEurovision();
    setupEurovision10_states(eurovision);
    // create 0 friendlies
    for (int i=0; i< 10; i++) {
        eurovisionAddVote(eurovision, i, (i+1)%10);
    }
    List result = eurovisionRunGetFriendlyStates(eurovision);
    CHECK(listGetSize(result), 0);
    CHECK(listGetFirst(result), NULL);
    printf(" SUCCESS\n");
    for (int i=0; i< 10; i+=2) { //add friendlies
        eurovisionRemoveVote(eurovision, i, (i+1)%10);
        eurovisionRemoveVote(eurovision, i+1, (i+2)%10);
        eurovisionAddVote(eurovision, i, i+1);
        eurovisionAddVote(eurovision, i+1, i);
    }
    listDestroy(result);
    printf("Testing all are friendlies: ");
    result = eurovisionRunGetFriendlyStates(eurovision);
    CHECK(listGetSize(result), 5);
    char* current;
    current = (char*)listGetFirst(result);
    CHECK(strcmp(current, "eight - nine"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "five - four"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "one - zero"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "seven - six"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "three - two"), 0);
    printf(" SUCCESS\n");
    eurovisionRemoveState(eurovision, 1);
    listDestroy(result);
    printf("Testing only part friendlies: ");
    result = eurovisionRunGetFriendlyStates(eurovision);
    CHECK(listGetSize(result), 4);
    current = (char*)listGetFirst(result);
    CHECK(strcmp(current, "eight - nine"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "five - four"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "seven - six"), 0);
    current = (char*)listGetNext(result);
    CHECK(strcmp(current, "three - two"), 0);
    printf(" SUCCESS\n");
    listDestroy(result);
    eurovisionDestroy(eurovision);
    return true;
}

bool testEmptyRun() {
    Eurovision eurovision = setupEurovision();
    printf("Testing empty contest: ");
    List result = eurovisionRunContest(eurovision, 60);
    CHECK(listGetFirst(result), NULL);
    CHECK(listGetSize(result), 0);
    listDestroy(result);
    result = eurovisionRunAudienceFavorite(eurovision);
    CHECK(listGetFirst(result), NULL);
    CHECK(listGetSize(result), 0);
    listDestroy(result);
    result = eurovisionRunGetFriendlyStates(eurovision);
    CHECK(listGetFirst(result), NULL);
    CHECK(listGetSize(result), 0);
    printf(" SUCCESS\n");
    listDestroy(result);
    eurovisionDestroy(eurovision);
    return true;
}

int main(int argc, char *argv[]) {
    RUN_TEST(testMapCreateDestroy);
    RUN_TEST(testIterator);
    RUN_TEST(testMapAddAndSize);
    RUN_TEST(testMapGet);
    TEST(testAddState)
    TEST(testRemoveState)
    TEST(testAddJudge)
    TEST(testRemoveJudge)
    TEST(testAddVote)
    TEST(testRemoveVote)
    TEST(testRunContest)
    TEST(testRunAudienceFavorite)
    TEST(testRunGetFriendlyStates)


    printf("\nWelcome to the homework 3 map_module tests, written by Vova Parakhin.\n\n---Passing those tests won't "
                                             "guarantee you a good grade---\nBut they might get you close to one "
                                             ",make some tests yourself to be sure.\n\n");
    printf("You can change w/e you want in the file itself but make sure \nto contact me if you want to upload");
    printf(" \'upgraded version\' of the file\n");
    printf("\nPress any button to start the tests:. \n\n");
    getchar();
    int tests_passed = 0;
    int tests_number = 0;
    tests_number += createDestroyTest(&tests_passed);
    tests_number += mapPutTest(&tests_passed);
    tests_number += mapGetSizeTest(&tests_passed);
    tests_number += mapCopyTest(&tests_passed);
    tests_number += mapContainsTest(&tests_passed);
    tests_number += mapRemoveTest(&tests_passed);
    tests_number += mapClearTest(&tests_passed);
    tests_number += mapGetTest(&tests_passed);
    print_grade(tests_number, tests_passed);

    testRemoveStateAndJudges();
    testJudgesScores();
    testAudienceScores();
    testFriendly();
    testEmptyRun();

    return 0;
}