#include "state.h"
#include "map.h"
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <stdbool.h>
#include <string.h>

typedef struct state_t {
    int id;
    char *stateName;
    char *songName;
    Map votes;
} *State;

int* copyInt(const int* number) {
    if (!number) {
        return NULL;
    }
    int *copy = malloc(sizeof(*copy));
    if (!copy) {
        return NULL;
    }
    *copy = *number;
    return copy;
}
void freeInt(int* number){
    free(number);
}
int compareInts(const int* number1, const int* number2){
    return (*number1 - *number2);
}

State stateCreate(int id, const char* stateName, const char* songName){
    State state = malloc(sizeof(*state));
    if(state == NULL){
        return NULL;
    }
    state->id = id;
    state->stateName = malloc((sizeof(char))*(strlen(stateName)+1));
    if(state->stateName == NULL){
        stateDestroy(state);
        return NULL;
    }
    strcpy_s((state->stateName), (strlen(stateName)+1), stateName);
    state->songName = malloc((sizeof(char))*(strlen(songName)+1));
    if(state->songName == NULL){
        stateDestroy(state);
        return NULL;
    }
    strcpy_s((state->songName), (strlen(songName)+1), songName);

    state->votes = mapCreate((copyMapDataElements)copyInt, (copyMapKeyElements)copyInt,
                             (freeMapDataElements)freeInt, (freeMapKeyElements)freeInt,
                             (compareMapKeyElements)compareInts);
    return state;
}

void stateDestroy(State state){
    if(state == NULL){
        return;
    }
    free(state->stateName);
    free(state->songName);
    mapDestroy(state->votes);
    free(state);
}

State stateCopy(State state){
    if(state == NULL){
        return NULL;
    }
    State newState = malloc(sizeof(*newState));
    if(newState == NULL){
        return NULL;
    }
    newState->id = state->id;
    newState->stateName = malloc((sizeof(char))*(strlen(((State)state)->stateName)+1));
    if(newState->stateName == NULL){
        stateDestroy(newState);
        return NULL;
    }
    strcpy_s((newState->stateName), (strlen(((State)state)->stateName)+1), (((State)state)->stateName));
    newState->songName = malloc((sizeof(char))*(strlen(((State)state)->songName)+1));
    if(newState->songName == NULL){
        stateDestroy(newState);
        return NULL;
    }
    strcpy_s((newState->songName), (strlen(((State)state)->songName)+1), (((State)state)->songName));
    newState->votes = mapCopy(((State)state)->votes);
    if(newState->votes == NULL){
        stateDestroy(newState);
        return NULL;
    }
    return newState;
}

bool addOneVote(State state, int stateTaker){
    int* stateVotes = mapGet(state->votes, &stateTaker);
    if(stateVotes != NULL) {
        *stateVotes = (*stateVotes) + 1;
        return true;
    }
    int firstVote = FIRST_VOTE;
    if(mapPut(state->votes, &stateTaker, &firstVote) != MAP_SUCCESS) {
        return false;
    }
    return true;
}

int getStateWithHighestVotes(Map map){
    int max = INITIAL_VALUE;
    int id = INITIAL_VALUE;
    int i = 1;
    MAP_FOREACH(int*, iterator, map) {
        int *votes = mapGet(map, iterator);
        if (votes != NULL) {
            if (i == 1) {
                id = *iterator;
                i++;
            }
            if (*votes == max) {
                if (id > *iterator) {
                    id = *iterator;
                }
            }
            if (*votes > max) {
                max = *votes;
                id = *iterator;
            }
        }
    }
    return id;
}

void removeOneVote(State state, int stateTaker){
    int* stateVotes = mapGet(state->votes, &stateTaker);
    if(stateVotes != NULL) {
        *stateVotes = (*stateVotes) - 1;
    }
}

int* topVotingStates(State state){
    if((state->votes) == NULL){
        return NULL;
    }
    int* audienceVotes = malloc(sizeof(audienceVotes) * DIFFERENT_VALID_SCORE);
    Map mapCopied = mapCopy(state->votes);
    int i = 0;
    int* iterator = mapGetFirst(mapCopied);
    while((i < DIFFERENT_VALID_SCORE) && (iterator != NULL)){
        int id = getStateWithHighestVotes(mapCopied);
        if(id == INITIAL_VALUE){
            while (i < DIFFERENT_VALID_SCORE){
                audienceVotes[i] = INITIAL_VALUE;
                i++;
            }
            mapDestroy(mapCopied);
            return audienceVotes;
        }
        mapRemove(mapCopied, &id);
        audienceVotes[i] = id;
        i++;
        iterator = mapGetFirst(mapCopied);
    }
    if(iterator == NULL){
        while (i < DIFFERENT_VALID_SCORE){
            audienceVotes[i] = INITIAL_VALUE;
            i++;
        }
    }
    mapDestroy(mapCopied);
    return audienceVotes;
}