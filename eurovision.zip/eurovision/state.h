#ifndef EUROVISION_STATE_H
#define EUROVISION_STATE_H

#define FIRST_VOTE 1
#define INITIAL_VALUE -1
#define DIFFERENT_VALID_SCORE 10

#include <stdbool.h>
#include "map.h"

/**
* State Container
*
* Implements a state container type.
*
* The following functions are available:
*   mapCreate		- Creates a new empty map
*   mapDestroy		- Deletes an existing map and frees all resources
*   mapCopy		- Copies an existing map
*/

/** Type for defining the state */
typedef struct state_t *State;

/** Type used for returning error codes from state functions */
typedef enum StateResult_t {
    STATE_SUCCESS,
    STATE_OUT_OF_MEMORY,
    STATE_NULL_ARGUMENT,
    STATE_ITEM_ALREADY_EXISTS,
    STATE_ITEM_DOES_NOT_EXIST
} StateResult;

/**
* stateCreate: Allocates a new state.
*
* @param copyDataElement - Function pointer to be used for copying data elements into
*  	the map or when copying the map.
* @param copyKeyElement - Function pointer to be used for copying key elements into
*  	the map or when copying the map.
* @param freeDataElement - Function pointer to be used for removing data elements from
* 		the map
* @param freeKeyElement - Function pointer to be used for removing key elements from
* 		the map
* @param compareKeyElements - Function pointer to be used for comparing key elements
* 		inside the map. Used to check if new elements already exist in the map.
* @return
* 	NULL - if one of the parameters is NULL or allocations failed.
* 	A new Map in case of success.
*/
State stateCreate(int id, const char* stateName, const char* songName);

/**
* mapDestroy: Deallocates an existing map. Clears all elements by using the
* stored free functions.
*
* @param map - Target map to be deallocated. If map is NULL nothing will be
* 		done
*/
void stateDestroy(State state);

/**
* mapCopy: Creates a copy of target map.
* Iterator values for both maps is undefined after this operation.
*
* @param map - Target map.
* @return
* 	NULL if a NULL was sent or a memory allocation failed.
* 	A Map containing the same elements as map otherwise.
*/
State stateCopy(State state);

bool addOneVote(State state, int stateTaker);

void removeOneVote(State state, int stateTaker);

int getStateWithHighestVotes(Map map);

int* topVotingStates(State state);








#endif //EUROVISION_STATE_H
