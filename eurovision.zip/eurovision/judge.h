#ifndef EUROVISION_JUDGE_H
#define EUROVISION_JUDGE_H

#include <stdbool.h>

#define JUDGE_SCORE 10

/**
* State Container
*
* Implements a state container type.
*
* The following functions are available:
*   mapCreate		- Creates a new empty map
*   mapDestroy		- Deletes an existing map and frees all resources
*   mapCopy		- Copies an existing map
*/

/** Type for defining the state */
typedef struct judge_t *Judge;

/** Type used for returning error codes from state functions */
typedef enum JudgeResult_t {
    JUDGE_SUCCESS,
    JUDGE_OUT_OF_MEMORY,
    JUDGE_NULL_ARGUMENT,
    JUDGE_ITEM_ALREADY_EXISTS,
    JUDGE_ITEM_DOES_NOT_EXIST
} JudgeResult;

/**
* stateCreate: Allocates a new state.
*
* @param copyDataElement - Function pointer to be used for copying data elements into
*  	the map or when copying the map.
* @param copyKeyElement - Function pointer to be used for copying key elements into
*  	the map or when copying the map.
* @param freeDataElement - Function pointer to be used for removing data elements from
* 		the map
* @param freeKeyElement - Function pointer to be used for removing key elements from
* 		the map
* @param compareKeyElements - Function pointer to be used for comparing key elements
* 		inside the map. Used to check if new elements already exist in the map.
* @return
* 	NULL - if one of the parameters is NULL or allocations failed.
* 	A new Map in case of success.
*/
Judge judgeCreate(int id, const char* judgeName, const int* scores);

/**
* mapDestroy: Deallocates an existing map. Clears all elements by using the
* stored free functions.
*
* @param map - Target map to be deallocated. If map is NULL nothing will be
* 		done
*/
void judgeDestroy(Judge judge);

/**
* mapCopy: Creates a copy of target map.
* Iterator values for both maps is undefined after this operation.
*
* @param map - Target map.
* @return
* 	NULL if a NULL was sent or a memory allocation failed.
* 	A Map containing the same elements as map otherwise.
*/
Judge judgeCopy(Judge judge);

bool judgeContainState(Judge judge, int stateId);

#endif //EUROVISION_JUDGE_H
