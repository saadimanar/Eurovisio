#ifndef EUROVISION_STATE_H
#define EUROVISION_STATE_H

#define FIRST_VOTE 1
#define INITIAL_VALUE -1
#define DIFFERENT_VALID_SCORE 10

#include <stdbool.h>
#include "map.h"

/**
* State Container
*
* Implements a state container type.
*
* The following functions are available:
*  stateCreate		          - Creates a new empty state
*  stateDestroy              - Deletes an existing state and frees all resources
*  stateCopy		          - Copies an existing state
*  addOneVote                - adds one vote to the state votes to the stateTaker
*  removeOneVote             - removes one vote of the state votes to the stateTaker
*  getStateWithHighestVotes  - returns the id of the state that gets from the given state's citizens' votes the highest votes number
*  topVotingStates           - returns array size 10 with the top voting to states
*  isValidName               - checks if the name of the state valid (contains small letters or space) or not
*/

/** Type for defining the state */
typedef struct state_t *State;

/** Type used for returning error codes from state functions */
typedef enum StateResult_t {
    STATE_SUCCESS,
    STATE_OUT_OF_MEMORY,
    STATE_NULL_ARGUMENT,
    STATE_ITEM_ALREADY_EXISTS,
    STATE_ITEM_DOES_NOT_EXIST
} StateResult;

/**
* stateCreate: Allocates a new state.
*
* @param id - the new state id
* @param stateName - the new state name
* @param songName_the - the new state songName
* @return
* 	NULL - if one of the parameters is NULL or allocations failed.
* 	A new State in case of success.
*/
State stateCreate(int id, const char* stateName, const char* songName);

/**
* stateDestroy: Deallocates an existing state. Clears all elements by using the
* stored free functions.
*
* @param state - Target state to be deallocated. If state is NULL nothing will be
* 		done
*/
void stateDestroy(State state);

/**
* stateCopy: Creates a copy of target state.
* @param state - Target state.
* @return
* 	NULL if a NULL was sent or a memory allocation failed.
* 	A State containing the same elements as state otherwise.
*/
State stateCopy(State state);

/**
 * addOneVote: adds one vote to the state votes to the stateTaker
 * @param state - Target state
 * @param stateTaker - the state to add one vote to
 * @return returns false if failed to add the vote otherwise true
 */
bool addOneVote(State state, int stateTaker);

/**
 * removeOneVote: removes one vote of the state votes to the stateTaker
 * @param state -Target state
 * @param stateTaker -the state to remove on vote from
 */
void removeOneVote(State state, int stateTaker);

/**
 * getStateWithHighestVotes: returns the id of the state that gets from the given state's citizens' votes the highest votes number
 * @param votes - the votes of the citizens of the target state
 * @return the the id of the state that gets from the given state's citizens' votes the highest votes number
 */
int getStateWithHighestVotes(Map votes);

/**
 * topVotingStates: returns array size 10 with the top voting to states
 * @param state -Target state
 * @return array size 10 with the top voting to states
 * if the state voted to less than 10 states then the rest of the array will contain INITIAL_VALUE
 */
int* topVotingStates(State state);

/**
 * isValidName: checks if the name of the state valid (contains small letters or space) or not
 * @param name - Target state name
 * @return returns true if the name is valid otherwise false
 */
bool isValidName(const char* name);

#endif //EUROVISION_STATE_H