#include "judge.h"
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <stdbool.h>
#include <string.h>

struct judge_t {
    int id;
    char *judgeName;
    int scores[JUDGE_SCORE];
};

Judge judgeCreate(int id, const char* judgeName, const int* scores){
    Judge judge = malloc(sizeof(*judge));
    if(judge == NULL){
        return NULL;
    }
    judge->id = id;
    judge->judgeName = malloc((sizeof(char))*(strlen(judgeName)+1));
    if(judge->judgeName == NULL){
        judgeDestroy(judge);
        return NULL;
    }
    strcpy((judge->judgeName), judgeName);

    for (int i = 0; i < JUDGE_SCORE; ++i) {
        (judge->scores)[i] = scores[i];
    }
    return judge;
}

void judgeDestroy(Judge judge){
    if(judge == NULL){
        return;
    }
    free(judge->judgeName);
    free(judge);
}

Judge judgeCopy(Judge judge){
    if(judge == NULL){
        return NULL;
    }
    Judge newJudge = malloc(sizeof(*newJudge));
    if(newJudge == NULL){
        return NULL;
    }
    newJudge->id = judge->id;
    newJudge->judgeName = malloc((sizeof(char))*(strlen(judge->judgeName)+1));
    if(newJudge->judgeName == NULL){
        judgeDestroy(newJudge);
        return NULL;
    }
    strcpy((newJudge->judgeName), judge->judgeName);

    for(int i=0; i < JUDGE_SCORE; i++){
        (newJudge->scores)[i] = (judge->scores)[i];
    }
    return newJudge;
}

bool judgeContainState(Judge judge, int stateId){
    if(judge == NULL){
        return false;
    }
    for (int i = 0; i < JUDGE_SCORE; ++i) {
        if((judge->scores)[i] == stateId){
            return true;
        }
    }
    return false;
}

bool isValidJudgeName(const char* judgeName) {
    int i = 0;
    while (judgeName[i]) {
        if (judgeName[i] != ' ') {
            if ((judgeName[i] < 'a') || (judgeName[i] > 'z')) {
                return false;
            }
        }
        i++;
    }
    return true;
}

int getNumberOfTimesAStateAppears(const int* stateIds, int stateId){
    int count = 0;
    for (int i = 0; i < JUDGE_SCORE; ++i) {
        if(stateIds[i] == stateId){
            count ++;
        }
    }
    return count;
}