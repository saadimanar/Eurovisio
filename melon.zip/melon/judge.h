#ifndef EUROVISION_JUDGE_H
#define EUROVISION_JUDGE_H

#include <stdbool.h>

#define JUDGE_SCORE 10

/**
* judge Container

* The following functions are available:
*   judgeCreate		                - Creates a new empty judge
*   judgeDestroy	                - Deletes an existing judge and frees all resources
*   judgeCopy		                - Copies an existing judge
*   judgeContainState              - returns weather or not a state exists inside the judge scores
*   isValidJudgeName               - checks if the name of the judge valid (contains small letters or space) or not
*   getNumberOfTimesAStateAppears  - counts the number of times a given state id appears in the given judge scores
*/

/** Type for defining the judge */
typedef struct judge_t *Judge;

/** Type used for returning error codes from judge functions */
typedef enum JudgeResult_t {
    JUDGE_SUCCESS,
    JUDGE_OUT_OF_MEMORY,
    JUDGE_NULL_ARGUMENT,
    JUDGE_ITEM_ALREADY_EXISTS,
    JUDGE_ITEM_DOES_NOT_EXIST
} JudgeResult;

/**
* judgeCreate: Allocates a new judge.
*
* @param id - the id of the judge
* @param judgeName - the name of the judge
* @param scores pointer to array size 10 that contains the states that the judge voted to
* @return
* 	NULL - if one of the parameters is NULL or allocations failed.
* 	A new judge in case of success.
*/
Judge judgeCreate(int id, const char* judgeName, const int* scores);

/**
* judgeDestroy: Deallocates an existing judge
*
* @param map - Target judge to be deallocated. If judge is NULL nothing will be
* 		done
*/
void judgeDestroy(Judge judge);

/**
* judgeCopy: Creates a copy of target judge.
* Iterator value is undefined after this operation.
*
* @param map - Target judge.
* @return
* 	NULL if a NULL was sent or a memory allocation failed.
* 	A judge containing the same elements as judge otherwise.
*/
Judge judgeCopy(Judge judge);

/**
 * judgeContainState: Checks if the judge voted to the state with the stateId that the function gets
 *
* @param judge - The judge to search in his array of scores
* @param stateId - The id of the state to look for.
* @return
* 	false - if one or more of the inputs is null, or if the id of the state was not found.
* 	true - if the stateid was found in the judge scores.
*/
bool judgeContainState(Judge judge, int stateId);

/**
 * isValidJudgeName: checks if the name of the judge valid (contains small letters or space) or not
 * @param judgeName - Target judge name
 * @return returns true if the name is valid otherwise false
 */
bool isValidJudgeName(const char* judgeName);

/**
 * getNumberOfTimesAStateAppears: counts the number of times a given state id appears in the given judge scores
 * @param stateIds - the states that the judge give score to it
 * @param stateId - the state id that is counted its appearance
 * @return returns true if the name is valid otherwise false
 */
int getNumberOfTimesAStateAppears(const int* stateIds, int stateId);

#endif //EUROVISION_JUDGE_H