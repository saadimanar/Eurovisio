
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "map.h"

typedef struct MapElements_t{
    MapDataElement data;
    MapKeyElement key;
    struct MapElements_t* next;
} MapElements;

struct Map_t{
    copyMapDataElements copyMapDataElements;
    copyMapKeyElements copyMapKeyElements;
    freeMapDataElements freeMapDataElements;
    freeMapKeyElements freeMapKeyElements;
    compareMapKeyElements compareMapKeyElements;
    MapElements* head;
    MapElements* iterator;
};

Map mapCreate(copyMapDataElements copyDataElement,
              copyMapKeyElements copyKeyElement,
              freeMapDataElements freeDataElement,
              freeMapKeyElements freeKeyElement,
              compareMapKeyElements compareKeyElements){

    if((!copyDataElement) || (!copyKeyElement) || (!freeDataElement) || (!freeKeyElement) || (!compareKeyElements)){
        return  NULL;
    }

    Map map = malloc(sizeof(*map));
    if(map == NULL){
        return NULL;
    }

    map->head = NULL;
    map->iterator = map->head;
    map->copyMapDataElements = copyDataElement;
    map->copyMapKeyElements = copyKeyElement;
    map->freeMapDataElements = freeDataElement;
    map->freeMapKeyElements = freeKeyElement;
    map->compareMapKeyElements = compareKeyElements;

    return map;
}

MapResult mapClear(Map map){

    if(map == NULL){
        return MAP_NULL_ARGUMENT;
    }
    MapKeyElement mapKeyElement = mapGetFirst(map);
    while(mapKeyElement != NULL){
        mapRemove(map, mapKeyElement);
        mapKeyElement = mapGetFirst(map);
    }
    return MAP_SUCCESS;
}

void mapDestroy(Map map){
    MapResult result = mapClear(map);
    if(result == MAP_NULL_ARGUMENT){
        return;
    }
    free(map);
}

Map mapCopy(Map map){
    if(map == NULL){
        return NULL;
    }

    Map new_map = mapCreate(map->copyMapDataElements,
                            map->copyMapKeyElements,
                            map->freeMapDataElements,
                            map->freeMapKeyElements,
                            map->compareMapKeyElements);

    if(new_map == NULL){
        return NULL;
    }

    MAP_FOREACH(MapKeyElement, iterator, map){
        MapDataElement mapDataElement = map->iterator->data;
        mapPut(new_map, iterator, mapDataElement);
    }
    return new_map;
}

int mapGetSize(Map map){
    if (map == NULL){
        return (-1);
    }
    if (map->head == NULL){
        return 0;
    }
    int size = 0;
    MapKeyElement mapKeyElement = mapGetFirst(map);
    while(mapKeyElement != NULL){
        size++;
        mapKeyElement = mapGetNext(map);
    }
    return size;
}

bool mapContains(Map map, MapKeyElement element){
    if((map == NULL) || (element == NULL)){
        return false;
    }
    MapKeyElement mapKeyElement = mapGetFirst(map);
    while(mapKeyElement != NULL){
        if (map->compareMapKeyElements(mapKeyElement, element) == 0){
            map->iterator = NULL;
            return true;
        }
        mapKeyElement = mapGetNext(map);
    }
    map->iterator = NULL;
    return false;
}

MapResult mapPut(Map map, MapKeyElement keyElement, MapDataElement dataElement) {
    if ((map == NULL) || (keyElement == NULL) || (dataElement == NULL)) {
        return MAP_NULL_ARGUMENT;
    }
    mapRemove(map, keyElement);
    MapElements* new_map_element = malloc(sizeof(*new_map_element));
    if (new_map_element == NULL) {
        return MAP_OUT_OF_MEMORY;
    }

    new_map_element->data = map->copyMapDataElements(dataElement);
    new_map_element->key = map->copyMapKeyElements(keyElement);
    new_map_element->next = NULL;

    if(map->head == NULL){
        map->head = new_map_element;
        map->iterator = map->head;
        return MAP_SUCCESS;
    }
    mapGetFirst(map);
    if (map->compareMapKeyElements(keyElement, map->iterator->key) < 0){
        new_map_element->next = map->iterator;
        map->head = new_map_element;
        return MAP_SUCCESS;
    }
    while(map->iterator->next != NULL) {
        if (map->compareMapKeyElements(keyElement, map->iterator->next->key) < 0) {
            new_map_element->next = map->iterator->next;
            map->iterator->next = new_map_element;
            return MAP_SUCCESS;
        }
        mapGetNext(map);
    }
    map->iterator->next = new_map_element;
    map->iterator = new_map_element->next;
    return MAP_SUCCESS;
}

MapDataElement mapGet(Map map, MapKeyElement keyElement){
    if((map == NULL) || (keyElement == NULL)){
        return NULL;
    }
    MapElements* ptr = map->iterator;
    if(!mapContains(map, keyElement)){
        map->iterator = ptr;
        return NULL;
    }
    MapKeyElement mapKeyElement = mapGetFirst(map);
    while(map->iterator != NULL){
        if (map->compareMapKeyElements(mapKeyElement,keyElement) == 0){
            MapDataElement mapDataElement = map->iterator->data;
            map->iterator = ptr;
            return (mapDataElement);
        }
        mapKeyElement = mapGetNext(map);
    }
    map->iterator = ptr;
    return NULL;
}

MapResult mapRemove(Map map, MapKeyElement keyElement){
    if (map == NULL || keyElement == NULL) {
        return MAP_NULL_ARGUMENT;
    }
    if(!mapContains(map, keyElement)) {
        return MAP_ITEM_DOES_NOT_EXIST;
    }
    if (map->compareMapKeyElements(map->head->key, keyElement) == 0){
        MapElements* ptr = map->head;
        if(map->head->next == NULL) {
            map->head = NULL;
            map->iterator = NULL;
        }else{
            map->head = map->head->next;
            map->iterator = map->head;
        }
        ptr->next = NULL;
        map->freeMapDataElements(ptr->data);
        map->freeMapKeyElements(ptr->key);
        free(ptr);
        return MAP_SUCCESS;
    }
    mapGetFirst(map);
    while (map->iterator->next != NULL) {
        MapElements* ptr = map->iterator->next;
        if (map->compareMapKeyElements(ptr->key, keyElement) == 0){
            map->iterator->next = ptr->next;
            map->freeMapDataElements(ptr->data);
            map->freeMapKeyElements(ptr->key);
            ptr->next = NULL;
            free(ptr);
            return MAP_SUCCESS;
        }
        mapGetNext(map);
    }
    return MAP_NULL_ARGUMENT;
}

MapKeyElement mapGetFirst(Map map){
    if(map == NULL){
        return NULL;
    }
    if (map->head == NULL){
        return NULL;
    }
    map->iterator = map->head;
    return(map->iterator->key);
}

MapKeyElement mapGetNext(Map map) {
    if (map == NULL) {
        return NULL;
    }
    if(map->iterator == NULL){
        return NULL;
    }
    if(map->iterator->next == NULL){
        map->iterator = map->iterator->next;
        return NULL;
    }
    map->iterator = map->iterator->next;
    return(map->iterator->key);
}